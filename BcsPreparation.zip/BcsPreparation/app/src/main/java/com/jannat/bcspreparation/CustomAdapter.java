package com.jannat.bcspreparation;



import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {
    private Context context;
    private List<ModelClass> Data;


    public CustomAdapter(Context context, List<ModelClass> data) {
        this.context = context;
        Data = data;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item,parent,false);
        return new MyViewHolder(view);
    }

    @SuppressLint("RecyclerView")
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.title.setText(Data.get(position).getTitle());
        holder.details.setText(Data.get(position).getTitle());

        Glide
                .with(context)
                .load(Data.get(position).getImage())
                .centerCrop()
                .placeholder(R.mipmap.ic_launcher)
                .into(holder.imageView);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(),DetailsActivity.class);
                intent.putExtra("title",Data.get(position).getTitle());
                intent.putExtra("details",Data.get(position).getDetails());
                intent.putExtra("imageData",Data.get(position).getImage());
                view.getContext().startActivity(intent);

            }
        });



    }

    @Override
    public int getItemCount() {
        return Data.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView title, details;
        ImageView imageView;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            title=itemView.findViewById(R.id.title);
            details=itemView.findViewById(R.id.details);
            imageView=itemView.findViewById(R.id.image);


        }
    }



}
