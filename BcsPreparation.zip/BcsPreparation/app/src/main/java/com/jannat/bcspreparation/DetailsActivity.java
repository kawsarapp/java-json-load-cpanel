package com.jannat.bcspreparation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class DetailsActivity extends AppCompatActivity {

    ImageView ImageViewId;
    TextView text_title_id, details_title_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        ImageViewId=findViewById(R.id.ImageViewId);
        text_title_id=findViewById(R.id.text_title_id);
        details_title_id=findViewById(R.id.details_title_id);

        Intent data = getIntent();
        String titleData = data.getStringExtra("title");
        String detailsData = data.getStringExtra("details");
        String img = data.getStringExtra("imageData");

        Glide
                .with(this)
                .load(img)
                .centerCrop()
                .placeholder(R.mipmap.ic_launcher)
                .into(ImageViewId);

        text_title_id.setText(titleData);
        details_title_id.setText(detailsData);


    }
}